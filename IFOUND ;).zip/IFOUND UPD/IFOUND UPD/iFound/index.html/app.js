// Firebase imports
import { initializeApp } from "https://www.gstatic.com/firebasejs/11.6.1/firebase-app.js";
import { getAuth, signInAnonymously, signInWithCustomToken, onAuthStateChanged } from "https://www.gstatic.com/firebasejs/11.6.1/firebase-auth.js";
import { getFirestore } from "https://www.gstatic.com/firebasejs/11.6.1/firebase-firestore.js";

// Global Firebase variables (same as original)
const appId = typeof __app_id !== 'undefined' ? __app_id : 'default-app-id';
const firebaseConfig = typeof __firebase_config !== 'undefined' ? JSON.parse(__firebase_config) : {};
const initialAuthToken = typeof __initial_auth_token !== 'undefined' ? __initial_auth_token : null;

// Form elements
const form = document.getElementById('login-form');
const emailInput = document.getElementById('email');
const passwordInput = document.getElementById('password');
const loginButton = document.getElementById('login-button');
const statusMessage = document.getElementById('status-message');

let isAuthReady = false;

// Status message function
function displayStatus(message, isError = false) {
    statusMessage.textContent = message;
    statusMessage.classList.remove('hidden', 'bg-red-100', 'text-red-700', 'bg-green-100', 'text-green-700');

    if (isError) {
        statusMessage.classList.add('bg-red-100', 'text-red-700');
    } else {
        statusMessage.classList.add('bg-green-100', 'text-green-700');
    }
}

// Firebase initialization
async function initializeFirebase() {
    try {
        if (Object.keys(firebaseConfig).length === 0) {
            console.error("Firebase config missing. Running mock mode.");
            return;
        }

        const app = initializeApp(firebaseConfig);
        const auth = getAuth(app);
        const db = getFirestore(app);

        onAuthStateChanged(auth, (user) => {
            console.log(user ? "Authenticated" : "Not authenticated");
            isAuthReady = true;
        });

        if (initialAuthToken) {
            await signInWithCustomToken(auth, initialAuthToken);
        } else {
            await signInAnonymously(auth);
        }

    } catch (error) {
        console.error("Firebase init error:", error);
        displayStatus(`Authentication error: ${error.message}`, true);
    }
}

// Login handler (same as original)
async function handleLogin(event) {
    event.preventDefault();

    const email = emailInput.value.trim();
    const password = passwordInput.value.trim();

    if (!email || !password) {
        displayStatus('Please enter both email and password.', true);
        return;
    }

    loginButton.textContent = 'Logging in...';
    loginButton.disabled = true;
    statusMessage.classList.add('hidden');

    while (!isAuthReady) {
        await new Promise(resolve => setTimeout(resolve, 100));
    }

    try {
        await new Promise(resolve => setTimeout(resolve, 1500));

        if (email === 'test@example.com' && password === 'password123') {
            displayStatus('Login successful! Redirecting...');
        } else {
            throw new Error("Invalid credentials. Use test@example.com / password123");
        }

    } catch (error) {
        displayStatus(`Login Failed: ${error.message}`, true);
    } finally {
        loginButton.textContent = 'Login';
        loginButton.disabled = false;
    }
}

form.addEventListener('submit', handleLogin);
initializeFirebase();
